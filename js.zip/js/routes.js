angular.module('app.routes', ['ionicUIRouter'])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('tabsController.xYBER', {
    url: '/homepage',
    views: {
      'tab5': {
        templateUrl: 'templates/xYBER.html',
        controller: 'xYBERCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.securityChecklistTopics'
      2) Using $state.go programatically:
        $state.go('tabsController.securityChecklistTopics');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab6/checklisttopic
      /page1/tab5/checklisttopic
  */
  .state('tabsController.securityChecklistTopics', {
    url: '/checklisttopic',
    views: {
      'tab6': {
        templateUrl: 'templates/securityChecklistTopics.html',
        controller: 'securityChecklistTopicsCtrl'
      },
      'tab5': {
        templateUrl: 'templates/securityChecklistTopics.html',
        controller: 'securityChecklistTopicsCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.quizTopics'
      2) Using $state.go programatically:
        $state.go('tabsController.quizTopics');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/quiztopics
      /page1/tab8/quiztopics
  */
  .state('tabsController.quizTopics', {
    url: '/quiztopics',
    views: {
      'tab5': {
        templateUrl: 'templates/quizTopics.html',
        controller: 'quizTopicsCtrl'
      },
      'tab8': {
        templateUrl: 'templates/quizTopics.html',
        controller: 'quizTopicsCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.cyberTipsTopics'
      2) Using $state.go programatically:
        $state.go('tabsController.cyberTipsTopics');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab7/page14
      /page1/tab5/page14
  */
  .state('tabsController.cyberTipsTopics', {
    url: '/page14',
    views: {
      'tab7': {
        templateUrl: 'templates/cyberTipsTopics.html',
        controller: 'cyberTipsTopicsCtrl'
      },
      'tab5': {
        templateUrl: 'templates/cyberTipsTopics.html',
        controller: 'cyberTipsTopicsCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.passwordChecker'
      2) Using $state.go programatically:
        $state.go('tabsController.passwordChecker');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/passwordchecker
      /page1/tab9/passwordchecker
  */
  .state('tabsController.passwordChecker', {
    url: '/passwordchecker',
    views: {
      'tab5': {
        templateUrl: 'templates/passwordChecker.html',
        controller: 'passwordCheckerCtrl'
      },
      'tab9': {
        templateUrl: 'templates/passwordChecker.html',
        controller: 'passwordCheckerCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.passwordCheckerResults'
      2) Using $state.go programatically:
        $state.go('tabsController.passwordCheckerResults');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/passwordresults
      /page1/tab9/passwordresults
  */
  .state('tabsController.passwordCheckerResults', {
    url: '/passwordresults',
    views: {
      'tab5': {
        templateUrl: 'templates/passwordCheckerResults.html',
        controller: 'passwordCheckerResultsCtrl'
      },
      'tab9': {
        templateUrl: 'templates/passwordCheckerResults.html',
        controller: 'passwordCheckerResultsCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.passwordGenerator'
      2) Using $state.go programatically:
        $state.go('tabsController.passwordGenerator');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/passgenerate
      /page1/tab10/passgenerate
  */
  .state('tabsController.passwordGenerator', {
    url: '/passgenerate',
    views: {
      'tab5': {
        templateUrl: 'templates/passwordGenerator.html',
        controller: 'passwordGeneratorCtrl'
      },
      'tab10': {
        templateUrl: 'templates/passwordGenerator.html',
        controller: 'passwordGeneratorCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.securityChecklist'
      2) Using $state.go programatically:
        $state.go('tabsController.securityChecklist');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab6/checklist+
      /page1/tab5/checklist+
  */
  .state('tabsController.securityChecklist', {
    url: '/checklist+',
    views: {
      'tab6': {
        templateUrl: 'templates/securityChecklist.html',
        controller: 'securityChecklistCtrl'
      },
      'tab5': {
        templateUrl: 'templates/securityChecklist.html',
        controller: 'securityChecklistCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.cyberTips'
      2) Using $state.go programatically:
        $state.go('tabsController.cyberTips');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab7/cybertips
      /page1/tab5/cybertips
  */
  .state('tabsController.cyberTips', {
    url: '/cybertips',
    views: {
      'tab7': {
        templateUrl: 'templates/cyberTips.html',
        controller: 'cyberTipsCtrl'
      },
      'tab5': {
        templateUrl: 'templates/cyberTips.html',
        controller: 'cyberTipsCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.quizQuestion1'
      2) Using $state.go programatically:
        $state.go('tabsController.quizQuestion1');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/quiz1
      /page1/tab8/quiz1
  */
  .state('tabsController.quizQuestion1', {
    url: '/quiz1',
    views: {
      'tab5': {
        templateUrl: 'templates/quizQuestion1.html',
        controller: 'quizQuestion1Ctrl'
      },
      'tab8': {
        templateUrl: 'templates/quizQuestion1.html',
        controller: 'quizQuestion1Ctrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.quiz1WrongAnswer'
      2) Using $state.go programatically:
        $state.go('tabsController.quiz1WrongAnswer');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/quiz1wrong
      /page1/tab8/quiz1wrong
  */
  .state('tabsController.quiz1WrongAnswer', {
    url: '/quiz1wrong',
    views: {
      'tab5': {
        templateUrl: 'templates/quiz1WrongAnswer.html',
        controller: 'quiz1WrongAnswerCtrl'
      },
      'tab8': {
        templateUrl: 'templates/quiz1WrongAnswer.html',
        controller: 'quiz1WrongAnswerCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.quiz2WrongAnswer'
      2) Using $state.go programatically:
        $state.go('tabsController.quiz2WrongAnswer');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/quiz2wrong
      /page1/tab8/quiz2wrong
  */
  .state('tabsController.quiz2WrongAnswer', {
    url: '/quiz2wrong',
    views: {
      'tab5': {
        templateUrl: 'templates/quiz2WrongAnswer.html',
        controller: 'quiz2WrongAnswerCtrl'
      },
      'tab8': {
        templateUrl: 'templates/quiz2WrongAnswer.html',
        controller: 'quiz2WrongAnswerCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.quiz3WrongAnswer'
      2) Using $state.go programatically:
        $state.go('tabsController.quiz3WrongAnswer');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/quiz3wrong
      /page1/tab8/quiz3wrong
  */
  .state('tabsController.quiz3WrongAnswer', {
    url: '/quiz3wrong',
    views: {
      'tab5': {
        templateUrl: 'templates/quiz3WrongAnswer.html',
        controller: 'quiz3WrongAnswerCtrl'
      },
      'tab8': {
        templateUrl: 'templates/quiz3WrongAnswer.html',
        controller: 'quiz3WrongAnswerCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.quiz4WrongAnswer'
      2) Using $state.go programatically:
        $state.go('tabsController.quiz4WrongAnswer');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/quiz4wrong
      /page1/tab8/quiz4wrong
  */
  .state('tabsController.quiz4WrongAnswer', {
    url: '/quiz4wrong',
    views: {
      'tab5': {
        templateUrl: 'templates/quiz4WrongAnswer.html',
        controller: 'quiz4WrongAnswerCtrl'
      },
      'tab8': {
        templateUrl: 'templates/quiz4WrongAnswer.html',
        controller: 'quiz4WrongAnswerCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.quiz5WrongAnswer'
      2) Using $state.go programatically:
        $state.go('tabsController.quiz5WrongAnswer');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/quiz5wrong
      /page1/tab8/quiz5wrong
  */
  .state('tabsController.quiz5WrongAnswer', {
    url: '/quiz5wrong',
    views: {
      'tab5': {
        templateUrl: 'templates/quiz5WrongAnswer.html',
        controller: 'quiz5WrongAnswerCtrl'
      },
      'tab8': {
        templateUrl: 'templates/quiz5WrongAnswer.html',
        controller: 'quiz5WrongAnswerCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.quizQuestion2'
      2) Using $state.go programatically:
        $state.go('tabsController.quizQuestion2');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/quiz2
      /page1/tab8/quiz2
  */
  .state('tabsController.quizQuestion2', {
    url: '/quiz2',
    views: {
      'tab5': {
        templateUrl: 'templates/quizQuestion2.html',
        controller: 'quizQuestion2Ctrl'
      },
      'tab8': {
        templateUrl: 'templates/quizQuestion2.html',
        controller: 'quizQuestion2Ctrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.quizQuestion3'
      2) Using $state.go programatically:
        $state.go('tabsController.quizQuestion3');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/quiz3
      /page1/tab8/quiz3
  */
  .state('tabsController.quizQuestion3', {
    url: '/quiz3',
    views: {
      'tab5': {
        templateUrl: 'templates/quizQuestion3.html',
        controller: 'quizQuestion3Ctrl'
      },
      'tab8': {
        templateUrl: 'templates/quizQuestion3.html',
        controller: 'quizQuestion3Ctrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.quizQuestion4'
      2) Using $state.go programatically:
        $state.go('tabsController.quizQuestion4');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/quiz4
      /page1/tab8/quiz4
  */
  .state('tabsController.quizQuestion4', {
    url: '/quiz4',
    views: {
      'tab5': {
        templateUrl: 'templates/quizQuestion4.html',
        controller: 'quizQuestion4Ctrl'
      },
      'tab8': {
        templateUrl: 'templates/quizQuestion4.html',
        controller: 'quizQuestion4Ctrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.quizQuestion5'
      2) Using $state.go programatically:
        $state.go('tabsController.quizQuestion5');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/quiz5
      /page1/tab8/quiz5
  */
  .state('tabsController.quizQuestion5', {
    url: '/quiz5',
    views: {
      'tab5': {
        templateUrl: 'templates/quizQuestion5.html',
        controller: 'quizQuestion5Ctrl'
      },
      'tab8': {
        templateUrl: 'templates/quizQuestion5.html',
        controller: 'quizQuestion5Ctrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.quizSuccessfullyCompleted'
      2) Using $state.go programatically:
        $state.go('tabsController.quizSuccessfullyCompleted');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/quizdone
      /page1/tab8/quizdone
  */
  .state('tabsController.quizSuccessfullyCompleted', {
    url: '/quizdone',
    views: {
      'tab5': {
        templateUrl: 'templates/quizSuccessfullyCompleted.html',
        controller: 'quizSuccessfullyCompletedCtrl'
      },
      'tab8': {
        templateUrl: 'templates/quizSuccessfullyCompleted.html',
        controller: 'quizSuccessfullyCompletedCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.passwordGenerated'
      2) Using $state.go programatically:
        $state.go('tabsController.passwordGenerated');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/onlynumbers
      /page1/tab10/onlynumbers
  */
  .state('tabsController.passwordGenerated', {
    url: '/onlynumbers',
    views: {
      'tab5': {
        templateUrl: 'templates/passwordGenerated.html',
        controller: 'passwordGeneratedCtrl'
      },
      'tab10': {
        templateUrl: 'templates/passwordGenerated.html',
        controller: 'passwordGeneratedCtrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.passwordGenerated2'
      2) Using $state.go programatically:
        $state.go('tabsController.passwordGenerated2');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/onlycharacters
      /page1/tab10/onlycharacters
  */
  .state('tabsController.passwordGenerated2', {
    url: '/onlycharacters',
    views: {
      'tab5': {
        templateUrl: 'templates/passwordGenerated2.html',
        controller: 'passwordGenerated2Ctrl'
      },
      'tab10': {
        templateUrl: 'templates/passwordGenerated2.html',
        controller: 'passwordGenerated2Ctrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.passwordGenerated3'
      2) Using $state.go programatically:
        $state.go('tabsController.passwordGenerated3');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/alphanumeric
      /page1/tab10/alphanumeric
  */
  .state('tabsController.passwordGenerated3', {
    url: '/alphanumeric',
    views: {
      'tab5': {
        templateUrl: 'templates/passwordGenerated3.html',
        controller: 'passwordGenerated3Ctrl'
      },
      'tab10': {
        templateUrl: 'templates/passwordGenerated3.html',
        controller: 'passwordGenerated3Ctrl'
      }
    }
  })

  /* 
    The IonicUIRouter.js UI-Router Modification is being used for this route.
    To navigate to this route, do NOT use a URL. Instead use one of the following:
      1) Using the ui-sref HTML attribute:
        ui-sref='tabsController.passwordGenerated4'
      2) Using $state.go programatically:
        $state.go('tabsController.passwordGenerated4');
    This allows your app to figure out which Tab to open this page in on the fly.
    If you're setting a Tabs default page or modifying the .otherwise for your app and
    must use a URL, use one of the following:
      /page1/tab5/alphaspecial
      /page1/tab10/alphaspecial
  */
  .state('tabsController.passwordGenerated4', {
    url: '/alphaspecial',
    views: {
      'tab5': {
        templateUrl: 'templates/passwordGenerated4.html',
        controller: 'passwordGenerated4Ctrl'
      },
      'tab10': {
        templateUrl: 'templates/passwordGenerated4.html',
        controller: 'passwordGenerated4Ctrl'
      }
    }
  })

$urlRouterProvider.otherwise('/page1/tab5/onlynumbers')

  

});