angular.module('app.controllers', [])
     
.controller('xYBERCtrl', function($scope) {

})
   
.controller('securityChecklistTopicsCtrl', function($scope) {

})
   
.controller('quizTopicsCtrl', function($scope) {

})
   
.controller('cyberTipsTopicsCtrl', function($scope) {

})
   
.controller('passwordCheckerCtrl', function($scope) {

})
   
.controller('passwordCheckerResultsCtrl', function($scope) {

})
   
.controller('passwordGeneratorCtrl', function($scope) {

})
   
.controller('securityChecklistCtrl', function($scope) {

})
   
.controller('cyberTipsCtrl', function($scope) {

})
   
.controller('quizQuestion1Ctrl', function($scope) {

})
   
.controller('quiz1WrongAnswerCtrl', function($scope) {

})
   
.controller('quiz2WrongAnswerCtrl', function($scope) {

})
   
.controller('quiz3WrongAnswerCtrl', function($scope) {

})
   
.controller('quiz4WrongAnswerCtrl', function($scope) {

})
   
.controller('quiz5WrongAnswerCtrl', function($scope) {

})
   
.controller('quizQuestion2Ctrl', function($scope) {

})
   
.controller('quizQuestion3Ctrl', function($scope) {

})
   
.controller('quizQuestion4Ctrl', function($scope) {

})
   
.controller('quizQuestion5Ctrl', function($scope) {

})
   
.controller('quizSuccessfullyCompletedCtrl', function($scope) {

})
   
.controller('passwordGeneratedCtrl', function($scope) {

})
   
.controller('passwordGenerated2Ctrl', function($scope) {

})
   
.controller('passwordGenerated3Ctrl', function($scope) {

})
   
.controller('passwordGenerated4Ctrl', function($scope) {

})
 